package J07033;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scn = new Scanner(new File("SINHVIEN.in"));
        ArrayList<SinhVien> a = new ArrayList<>();
        int n = Integer.parseInt(scn.nextLine());
        while (n-- > 0) {
            a.add(new SinhVien(scn.nextLine(), scn.nextLine().trim(), scn.nextLine(), scn.nextLine()));
        }
        Collections.sort(a);
        for (SinhVien i : a) System.out.println(i);
    }
}
