package J04021;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class IntSet {
    private TreeSet<Integer> s = new TreeSet<>();

    public IntSet(int[] a) {
        for (int i : a) s.add(i);
    }

    public IntSet(TreeSet<Integer> s) {
        this.s = s;
    }

    public IntSet union(IntSet o) {
        TreeSet<Integer> ans = new TreeSet<>(s);
        ans.addAll(o.s);
        return new IntSet(ans);
    }

    @Override
    public String toString() {
        String res = "";
        for (int i : s) {
            res += i + " ";
        }
        return res;
    }
}
