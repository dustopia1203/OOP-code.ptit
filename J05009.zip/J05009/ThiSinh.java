package J05009;

public class ThiSinh implements Comparable<ThiSinh>{
    private static int cnt = 0;
    private int id = ++cnt;
    private String name, dob;
    private float p1, p2, p3, sum;

    public ThiSinh(String name, String dob, String p1, String p2, String p3) {
        this.name = name;
        this.dob = dob;
        this.p1 = Float.parseFloat(p1);
        this.p2 = Float.parseFloat(p2);
        this.p3 = Float.parseFloat(p3);
        this.sum = this.p1 + this.p2 + this.p3;
    }

    public float getSum() {
        return sum;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + dob + " " + String.format("%.01f", sum);
    }

    @Override
    public int compareTo(ThiSinh o) {
        if (sum == o.sum) return Integer.compare(id, o.id);
        return -Float.compare(sum, o.sum);
    }
}
