package J05009;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        ArrayList<ThiSinh> a = new ArrayList<>();
        int n = Integer.parseInt(scn.nextLine());
        while (n-- > 0) {
            a.add(new ThiSinh(scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine()));
        }
        Collections.sort(a);
        float max = a.get(0).getSum();
        for (ThiSinh i : a) {
            if (i.getSum() < max) break;
            System.out.println(i);
        }
    }
}
