package J04011;

public class Point3D {

    int x, y, z;

    Point3D() {
    }

    Point3D(int a, int b, int c) {
        x = a;
        y = b;
        z = c;
    }

    public static boolean check(Point3D a, Point3D b, Point3D c, Point3D d) {
        int a1 = b.x - a.x;
        int b1 = b.y - a.y;
        int c1 = b.z - a.z;
        int a2 = c.x - a.x;
        int b2 = c.y - a.y;
        int c2 = c.z - a.z;
        int fa = b1 * c2 - b2 * c1;
        int fb = a2 * c1 - a1 * c2;
        int fc = a1 * b2 - b1 * a2;
        int fd = (-fa * a.x - fb * a.y - fc * a.z);
        return (fa * d.x + fb * d.y + fc * d.z + fd) == 0;

    }

}