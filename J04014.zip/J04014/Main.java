package J04014;

import java.util.Scanner;

public class Main {
    public static long gcd(long a, long b) {
        while (b > 0) {
            long tmp = b;
            b = a % b;
            a = tmp;
        }
        return a;
    }

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int t = scn.nextInt();
        while (t-- > 0) {
            PhanSo a = new PhanSo(scn.nextLong(), scn.nextLong());
            PhanSo b = new PhanSo(scn.nextLong(), scn.nextLong());
            PhanSo c = (a.add(b)).mul(a.add(b)).reduce();
            PhanSo d = a.mul(b.mul(c)).reduce();
            System.out.println(c + " " + d);
        }
    }
}
