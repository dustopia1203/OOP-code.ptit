package J04014;

public class PhanSo {
    private long tu, mau;

    public PhanSo(long tu, long mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public PhanSo reduce() {
        return new PhanSo(tu / Main.gcd(tu, mau), mau / Main.gcd(tu, mau));
    }

    public PhanSo add(PhanSo o) {
        return new PhanSo(tu * o.mau + o.tu * mau, mau * o.mau).reduce();
    }

    public PhanSo mul(PhanSo o) {
        return new PhanSo(tu * o.tu, mau * o.mau).reduce();
    }

    @Override
    public String toString() {
        return tu + "/" + mau;
    }
}
