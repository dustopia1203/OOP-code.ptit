package J04004;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        long a = scn.nextLong(), b = scn.nextLong(), c = scn.nextLong(), d = scn.nextLong();
        PhanSo ps1 = new PhanSo(a, b), ps2 = new PhanSo(c, d);
        System.out.println(ps1.tongPhanSo(ps2));
    }
}
