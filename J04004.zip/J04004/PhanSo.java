package J04004;

public class PhanSo {
    public static long gcd(long a, long b) {
        if (b == 0) return a;
        else return gcd(b, a % b);
    }
    private long tuSo, mauSo;
    PhanSo(long tuSo, long mauSo) {
        this.tuSo = tuSo;
        this.mauSo = mauSo;
    }

    public PhanSo rutGon() {
        long tmp = gcd(tuSo, mauSo);
        return new PhanSo(tuSo / tmp, mauSo / tmp);
    }

    public PhanSo tongPhanSo(PhanSo a) {
        long tu = this.tuSo * a.mauSo + this.mauSo * a.tuSo;
        long mau = this.mauSo * a.mauSo;
        return new PhanSo(tu, mau).rutGon();
    }

    @Override
    public String toString() {
        return Long.toString(tuSo) + "/" + Long.toString(mauSo);
    }
}
