package J06007;

import java.util.*;

public class GiangVien {
    private Map<Mon, Double> m = new HashMap<>();
    private String id, name;
    private double sH = 0;

    public GiangVien(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return name + " " + String.format("%.02f", sH);
    }

    public void updatesH(Mon mon, double d) {
        m.put(mon, d);
        sH += d;
    }

    public GiangVien getGiangVien(String s) {
        if (s.equals(id)) return this;
        else return null;
    }
}
