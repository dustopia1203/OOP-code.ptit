package J06007;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int n = Integer.parseInt(scn.nextLine());
        ArrayList<Mon> mons = new ArrayList<>();
        while (n-- > 0) {
            String[] tok = scn.nextLine().split("\\s");
            String id = tok[0];
            String name = "";
            for (int i = 1; i < tok.length; i++) name += tok[i] + " ";
            name = name.trim();
            mons.add(new Mon(id, name));
        }
        n = Integer.parseInt(scn.nextLine());
        ArrayList<GiangVien> gvs = new ArrayList<>();
        while (n-- > 0) {
            String[] tok = scn.nextLine().split("\\s");
            String id = tok[0];
            String name = "";
            for (int i = 1; i < tok.length; i++) name += tok[i] + " ";
            name = name.trim();
            gvs.add(new GiangVien(id, name));
        }
        n = Integer.parseInt(scn.nextLine());
        while (n-- > 0) {
            String[] tok = scn.nextLine().split("\\s");
            String idgv = tok[0];
            String idm = tok[1];
            double d = Double.parseDouble(tok[2]);
            for (GiangVien i : gvs) {
                if (i.getGiangVien(idgv) != null) {
                    for (Mon j : mons) {
                        if (j.getMon(idm) != null) {
                            i.updatesH(j, d);
                        }
                    }
                }
            }
        }
        for (GiangVien i : gvs) {
            System.out.println(i);
        }
    }
}
