package J06007;

public class Mon {
    private String id, name;

    public Mon(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public Mon getMon(String s) {
        if (s.equals(id)) return this;
        else return null;
    }
}
