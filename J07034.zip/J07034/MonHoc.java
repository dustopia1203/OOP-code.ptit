package J07034;

public class MonHoc implements Comparable<MonHoc>{
    private String ma, ten;
    private int sotc;

    public MonHoc(String ma, String ten, String sotc) {
        this.ma = ma;
        this.ten = ten;
        this.sotc = Integer.parseInt(sotc);
    }

    @Override
    public String toString() {
        return ma + " " + ten + " " + sotc;
    }

    @Override
    public int compareTo(MonHoc o) {
        return this.ten.compareTo(o.ten);
    }
}
