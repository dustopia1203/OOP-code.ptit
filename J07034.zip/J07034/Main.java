package J07034;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scn = new Scanner(new File("MONHOC.in"));
        int n = Integer.parseInt(scn.nextLine());
        ArrayList<MonHoc> a = new ArrayList<>();
        while (n-- > 0) {
            a.add(new MonHoc(scn.nextLine(), scn.nextLine(), scn.nextLine()));
        }
        Collections.sort(a);
        for (MonHoc i : a) {
            System.out.println(i);
        }
    }
}
