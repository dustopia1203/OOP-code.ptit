package J07058;

import java.util.Comparator;

public class MonHoc {
    private String maMon, tenMon, hinhThucThi;
    MonHoc(String maMon, String tenMon, String hinhThucThi) {
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.hinhThucThi = hinhThucThi;
    }

    public String getMaMon() {
        return maMon;
    }

    @Override
    public String toString() {
        return String.format("%s %s %s", maMon, tenMon, hinhThucThi);
    }
}
