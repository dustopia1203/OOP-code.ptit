package J07084;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class SinhVien implements Comparable<SinhVien> {
    private String name;
    private Date start, end;
    private Long duration;

    public SinhVien(String name, String start, String end) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        this.name = name;
        this.start = formatter.parse(start);
        this.end = formatter.parse(end);
        duration = ChronoUnit.MINUTES.between(this.start.toInstant(), this.end.toInstant());
    }

    @Override
    public String toString() {
        return this.name + " " + this.duration;
    }

    @Override
    public int compareTo(SinhVien o) {
        if (this.duration == o.duration) return this.name.compareTo(o.name);
        return -this.duration.compareTo(o.duration);
    }
}
