package J06008;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int n = Integer.parseInt(scn.nextLine());
        ArrayList<Mon> a = new ArrayList<>();
        while (n-- > 0) {
            String s = scn.nextLine();
            String[] tok = s.split("\\s");
            String s1 = tok[0];
            String s2 = "";
            for (int i = 1; i < tok.length; i++) s2 += tok[i] + " ";
            s2 = s2.trim();
            a.add(new Mon(s1, s2));
        }
        n = Integer.parseInt(scn.nextLine());
        ArrayList<GiaoVien> b = new ArrayList<>();
        while (n-- > 0) {
            String s = scn.nextLine();
            String[] tok = s.split("\\s");
            String s1 = tok[0];
            String s2 = "";
            for (int i = 1; i < tok.length; i++) s2 += tok[i] + " ";
            s2 = s2.trim();
            b.add(new GiaoVien(s1, s2));
        }
        n = Integer.parseInt(scn.nextLine());
        while (n-- > 0) {
            String s = scn.nextLine();
            String[] tok = s.split("\\s");
            String s1 = tok[0];
            String s2 = tok[1];
            double d1 = Double.parseDouble(tok[2]);
            for (GiaoVien i : b) {
                if (i.getGiaoVien(s1) != null) {
                    for (Mon j : a) {
                        if (j.getMon(s2) != null) {
                            i.setMon(j.getMon(s2), d1);
                        }
                    }
                }
            }
        }
        String s = scn.nextLine();
        for (GiaoVien i : b) {
            i.thongKe(s);
        }
    }
}
