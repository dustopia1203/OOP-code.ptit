package J06008;

import java.util.*;

public class GiaoVien {
    private String id, name;
    private Map<Mon, Double> m = new HashMap<>();
    private ArrayList<Mon> a = new ArrayList<>();
    private double sH = 0;

    public GiaoVien(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public void setMon(Mon mon, double d) {
        m.put(mon, d);
        a.add(mon);
        sH += d;
    }

    public GiaoVien getGiaoVien(String s) {
        if (s.equals(id)) {
            return this;
        } else return null;
    }

    public void thongKe(String s) {
        if (s.equals(id)) {
            System.out.println("Giang vien: " + name);
            for (Mon i : a) {
                System.out.println(i + " " + m.get(i));
            }
            System.out.printf("Tong: %.02f", sH);
        } else return;
    }
}
