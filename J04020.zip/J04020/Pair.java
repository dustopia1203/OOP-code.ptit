package J04020;

public class Pair<V1, V2> {
    private V1 v1;
    private V2 v2;

    public Pair(V1 v1, V2 v2) {
        this.v1 = v1;
        this.v2 = v2;
    }

    public boolean check(int n) {
        if (n < 2) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) if (n % i == 0) return false;
        return true;
    }

    public boolean isPrime() {
        return check((Integer) v1) && (check((Integer) v2));
    }

    @Override
    public String toString() {
        return v1 + " " + v2;
    }
}
