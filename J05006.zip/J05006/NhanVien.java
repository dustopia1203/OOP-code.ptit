package J05006;

public class NhanVien {
    private static int cnt = 0;
    private String id = String.format("%05d", ++cnt);
    private String name, sex, dob, address, taxNumber, contractDay;

    public NhanVien(String name, String sex, String dob, String address, String taxNumber, String contractDay) {
        this.name = name;
        this.sex = sex;
        this.dob = dob;
        this.address = address;
        this.taxNumber = taxNumber;
        this.contractDay = contractDay;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + sex + " " + dob + " " + address + " " + taxNumber + " " + contractDay;
    }
}
