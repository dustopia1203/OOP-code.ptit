package J07081;

public class SinhVien implements Comparable<SinhVien> {
    private String id;
    private String name;
    private String firstName;
    private String lastName;
    private String middleName;
    private String phone;
    private String email;

    public SinhVien(String id, String name, String phone, String email) {
        this.id = id;
        String[] tmp = name.split("\\s+");
        this.name = tmp[0];
        for (int i = 1; i < tmp.length; ++i) this.name += (" " + tmp[i]);
        this.lastName = tmp[0];
        this.firstName = tmp[tmp.length - 1];
        if (tmp.length > 2) {
            this.middleName = tmp[1];
            for (int i = 2; i < tmp.length; ++i) this.middleName += (" " + tmp[i]);
        } else this.middleName = "";
        this.phone = phone;
        this.email = email;
    }
    
    @Override
    public int compareTo(SinhVien o) {
        if (!this.firstName.equals(o.firstName)) return this.firstName.compareTo(o.firstName);
        if (!this.lastName.equals(o.lastName)) return this.lastName.compareTo(o.lastName);
        if (!this.middleName.equals(o.middleName)) return this.middleName.compareTo(o.middleName);
        return this.id.compareTo(o.id);
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s", this.id, this.name, this.phone, this.email);
    }
}
