package J07081;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("SINHVIEN.in"));
        int n = sc.nextInt();
        ArrayList<SinhVien> a = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            String id = sc.next();
            sc.nextLine();
            String name = sc.nextLine();
            String phone = sc.next();
            String email = sc.next();
            a.add(new SinhVien(id, name, phone, email));
        }
        Collections.sort(a);
        for (SinhVien x : a) System.out.println(x);
    }
}
