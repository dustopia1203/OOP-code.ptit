package J04012;

import java.util.Objects;

public class NhanVien {
    private static int n = 1;
    private String id = String.format("NV%02d", n++);
    private String name;
    private int bwpd;
    private int d;
    private String lv;
    private int wg, bonus, extra, sum;

    public NhanVien(String name, String bwpd, String d, String lv) {
        this.name = name;
        this.bwpd = Integer.parseInt(bwpd);
        this.d = Integer.parseInt(d);
        this.lv = lv;
        wg = this.bwpd * this.d;
        if (this.d >= 25) {
            bonus = this.wg / 100 * 20;
        } else if (this.d >= 22) {
            bonus = this.wg / 100 * 10;
        } else bonus = 0;
        if (Objects.equals(this.lv, "GD")) extra = 250000;
        else if (Objects.equals(this.lv, "PGD")) extra = 200000;
        else if (Objects.equals(this.lv, "TP")) extra = 180000;
        else extra = 150000;
        sum = wg + bonus + extra;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + wg + " " + bonus + " " + extra + " " + sum;
    }
}
