package J04012;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        NhanVien a = new NhanVien(scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine());
        System.out.println(a);
    }
}
