package J05081;

public class MatHang implements Comparable<MatHang> {
    private String ma, ten, donVi;
    private int mua, ban, loi;

    public MatHang(int ma, String ten, String donVi, int mua, int ban) {
        this.ma = String.format("MH%03d", ma);
        this.ten = ten;
        this.donVi = donVi;
        this.mua = mua;
        this.ban = ban;
        loi = ban - mua;
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %d %d %d", ma, ten, donVi, mua, ban, loi);
    }


    @Override
    public int compareTo(MatHang o) {
        if (this.loi == o.loi) return this.ma.compareTo(o.ma);
        else if (this.loi > o.loi) return -1;
        else return 1;
    }
}
