package J05081;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int n = Integer.parseInt(scn.nextLine());
        ArrayList<MatHang> a = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            a.add(new MatHang(i, scn.nextLine(), scn.nextLine(), Integer.parseInt(scn.nextLine()), Integer.parseInt(scn.nextLine())));
        }
        Collections.sort(a);
        for (MatHang i : a) System.out.println(i);
    }
}
