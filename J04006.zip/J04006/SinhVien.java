package J04006;

public class SinhVien {
    private String hoTen, lop, ngaySinh, maSinhVien = "B20DCCN001";
    private double gpa;

    SinhVien(String hoTen, String lop, String ngaySinh, double gpa) {
        this.hoTen = hoTen;
        this.lop = lop;
        this.ngaySinh = ngaySinh;
        standardizedDateOfBirth();
        this.gpa = gpa;
    }

    public void standardizedDateOfBirth()
    {
        String[] a = this.ngaySinh.split("/");
        this.ngaySinh = "";
        while(a[0].length() < 2)
            a[0] = "0" + a[0];
        this.ngaySinh += a[0] + "/";
        while(a[1].length() < 2)
            a[1] = "0" + a[1];
        this.ngaySinh += a[1] + "/";
        while(a[2].length() < 4)
            a[2] = "0" + a[2];
        this.ngaySinh += a[2];
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s %.2f", maSinhVien, hoTen, lop, ngaySinh, gpa);
    }
}
