package J04006;

import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String hoTen = scn.nextLine();
        String lop = scn.nextLine();
        String ngaySinh = scn.nextLine();
        double gpa = scn.nextDouble();
        SinhVien a = new SinhVien(hoTen, lop, ngaySinh, gpa);
        System.out.println(a);
    }
}
