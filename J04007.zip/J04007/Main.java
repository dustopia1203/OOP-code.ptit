package J04007;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String[] s = new String[6];
        Scanner scn = new Scanner(System.in);
        for (int i = 0; i < 6; ++i) s[i] = scn.nextLine();
        NhanVien a = new NhanVien(s[0], s[1], s[2], s[3], s[4], s[5]);
        System.out.println(a);
    }
}
