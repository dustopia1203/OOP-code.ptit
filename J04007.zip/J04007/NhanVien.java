package J04007;

public class NhanVien {
    private String iD = "00001", name, gender, dob, address, taxId, contractDay;

    NhanVien(String name, String gender, String dob, String address, String taxId, String contractDay) {
        this.name = name;
        this.gender = gender;
        this.dob = dob;
        this.address = address;
        this.taxId = taxId;
        this.contractDay = contractDay;
    }

    @Override
    public String toString() {
        return iD + " " + name + " " + gender + " " + dob + " " + address + " " + taxId + " " + contractDay;
    }
}
