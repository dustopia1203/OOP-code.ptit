package J05004;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SinhVien {
    private static int cnt = 0;
    private String id, name, cls, dob;
    private float gpa;

    public SinhVien(String name, String cls, String dob, String gpa) throws ParseException {
        this.id = String.format("B20DCCN%03d", ++cnt);
        this.name = "";
        for (String i : name.trim().toLowerCase().split("\\s+")) {
            this.name += Character.toUpperCase(i.charAt(0)) + i.substring(1) + " ";
        }
        this.name = this.name.trim();
        this.cls = cls;
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        this.dob = formatter.format(formatter.parse(dob));
        this.gpa = Float.parseFloat(gpa);
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s %.02f", id, name, cls, dob, gpa);
    }
}