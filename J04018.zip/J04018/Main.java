package J04018;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int t = scn.nextInt();
        while (t-- > 0) {
            SoPhuc a = new SoPhuc(scn.nextLong(), scn.nextLong());
            SoPhuc b = new SoPhuc(scn.nextLong(), scn.nextLong());
            SoPhuc c = (a.add(b)).mul(a);
            SoPhuc d = (a.add(b)).mul(a.add(b));
            System.out.println(c + ", " + d);
        }
    }
}
