package J04018;

public class SoPhuc {
    private long r, i;

    public SoPhuc(long a, long b) {
        r = a;
        i = b;
    }

    public SoPhuc add(SoPhuc o) {
        return new SoPhuc(r + o.r, i + o.i);
    }

    public SoPhuc mul(SoPhuc o) {
        return new SoPhuc(r * o.r - i * o.i, r * o.i + i * o.r);
    }

    @Override
    public String toString() {
        return r + " + " + i + "i";
    }
}
