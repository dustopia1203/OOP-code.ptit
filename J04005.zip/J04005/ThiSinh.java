package J04005;

public class ThiSinh {
    private String hoTen, ngaySinh;
    private double diem1, diem2, diem3, tongDiem;
    ThiSinh(String hoTen, String ngaySinh, double diem1, double diem2, double diem3)  {
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.diem1 = diem1;
        this.diem2 = diem2;
        this.diem3 = diem3;
        this.tongDiem = diem1 + diem2 + diem3;
    }

    @Override
    public String toString() {
        return String.format("%s %s %.1f", hoTen, ngaySinh, tongDiem);
    }
}
