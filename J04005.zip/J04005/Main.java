package J04005;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String hoTen = scn.nextLine();
        String ngaySinh = scn.nextLine();
        double diem1 = Double.parseDouble(scn.nextLine());
        double diem2 = Double.parseDouble(scn.nextLine());
        double diem3 = Double.parseDouble(scn.nextLine());
        ThiSinh a =  new ThiSinh(hoTen, ngaySinh, diem1, diem2, diem3);
        System.out.println(a);
    }
}
