package J07017;

public class Pair<K, V> {
    private K a;
    private V b;
    public Pair(K a, V b) {
        this.a = a;
        this.b = b;
    }
    public boolean checkK(K a) {
        int n = (Integer) a;
        if (n < 2) return false;
        for (int i = 2; i <= Math.sqrt(n); ++i) if (n % i == 0) return false;
        return true;
    }

    public boolean checkV(V a) {
        int n = (Integer) a;
        if (n < 2) return false;
        for (int i = 2; i <= Math.sqrt(n); ++i) if (n % i == 0) return false;
        return true;
    }

    public boolean isPrime() {
        if (checkK(a) && checkV(b)) return true;
        return false;
    }

    @Override
    public String toString() {
        return a.toString() + " " + b.toString();
    }
}
