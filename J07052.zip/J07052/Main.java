package J07052;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("THISINH.in")).useLocale(Locale.getDefault());
        int n = sc.nextInt();
        ArrayList<ThiSinh> a = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            String id = sc.next();
            sc.nextLine();
            String name = sc.nextLine();
            float toan = sc.nextFloat();
            float ly = sc.nextFloat();
            float hoa = sc.nextFloat();
            a.add(new ThiSinh(id, name, toan, ly, hoa));
        }
        int num = sc.nextInt();
        Collections.sort(a);
        float minMark = a.get(num - 1).getMark();
        System.out.printf("%.1f\n", minMark);
        for (ThiSinh x : a) x.setStatus(x.getMark() >= minMark ? "TRUNG TUYEN" : "TRUOT");
        for (ThiSinh x : a) System.out.println(x);
    }
}
