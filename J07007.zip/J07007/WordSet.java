package J07007;

import java.io.*;
import java.util.*;

public class WordSet {
    private Set<String> s;

    public WordSet(String fp) throws FileNotFoundException {
        Scanner scn = new Scanner(new File(fp));
        Set<String> s = new TreeSet<String>();
        while (scn.hasNext()) s.add(scn.next().toLowerCase());
        this.s = s;
    }

    @Override
    public String toString() {
        StringBuilder res = new StringBuilder();
        for (String x : s)
            res.append(x).append("\n");
        return res.toString();
    }
}
