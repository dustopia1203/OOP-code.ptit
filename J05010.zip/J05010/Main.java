package J05010;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int n = Integer.parseInt(scn.nextLine());
        ArrayList<MatHang> a = new ArrayList<>();
        while (n-- > 0) {
            a.add(new MatHang(scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine()));
        }
        Collections.sort(a);
        for (MatHang i : a) System.out.println(i);
    }
}
