package J05010;

public class MatHang implements Comparable<MatHang> {
    private static int cnt = 0;
    private int id = ++cnt;
    private String name, group;
    private float buy, sell, profit;

    public MatHang(String name, String group, String buy, String sell) {
        this.name = name;
        this.group = group;
        this.buy = Float.parseFloat(buy);
        this.sell = Float.parseFloat(sell);
        profit = - this.buy + this.sell;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + group + " " + String.format("%.02f", profit);
    }

    @Override
    public int compareTo(MatHang o) {
        return -Float.compare(this.profit, o.profit);
    }
}
