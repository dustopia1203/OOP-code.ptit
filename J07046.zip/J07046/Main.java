package J07046;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("KHACH.in"));
        int n = sc.nextInt();
        ArrayList<Khach> a = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            sc.nextLine();
            a.add(new Khach(sc.nextLine(), sc.next(), sc.next(), sc.next()));
        }
        Collections.sort(a);
        for (Khach x : a) System.out.println(x);
    }
}
