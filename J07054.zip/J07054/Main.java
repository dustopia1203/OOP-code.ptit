package J07054;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("BANGDIEM.in"));
        int n = sc.nextInt();
        ArrayList<SinhVien> a = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            sc.nextLine();
            a.add(new SinhVien(sc.nextLine(), sc.nextInt(), sc.nextInt(), sc.nextInt()));
        }
        Collections.sort(a);
        float currentVal = 0;
        int currentRank = 0;
        int tmp = 0;
        for (int i = 0; i < n; ++i) {
            if (currentVal == a.get(i).getAverage()) {
                a.get(i).setRank(currentRank);
                tmp += 1;
            } else {
                currentRank += (tmp + 1);
                tmp = 0;
                a.get(i).setRank(currentRank);
            }
            currentVal = a.get(i).getAverage();
        }
        for (SinhVien x : a) System.out.println(x);
    }
}
