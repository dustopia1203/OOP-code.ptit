package J07037;

public class DoanhNghiep implements Comparable<DoanhNghiep> {
    private String id;
    private String name;
    private int numOfSV;

    public DoanhNghiep(String id, String name, int numOfSV) {
        this.id = id;
        this.name = name;
        this.numOfSV = numOfSV;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumOfSV() {
        return numOfSV;
    }

    public void setNumOfSV(int numOfSV) {
        this.numOfSV = numOfSV;
    }

    @Override
    public int compareTo(DoanhNghiep o) {
        return this.id.compareTo(o.id);
    }

    @Override
    public String toString() {
        return String.format("%s %s %d", this.id, this.name, this.numOfSV);
    }
}
