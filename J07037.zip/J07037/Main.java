package J07037;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("DN.in"));
        int n = sc.nextInt();
        ArrayList<DoanhNghiep> a = new ArrayList<>();
        for (int i = 0; i < n; ++i) {
            String id = sc.next();
            sc.nextLine();
            String name = sc.nextLine();
            int numOfSV = sc.nextInt();
            a.add(new DoanhNghiep(id, name, numOfSV));
        }
        Collections.sort(a);
        for (DoanhNghiep x : a) System.out.println(x);
    }
}
