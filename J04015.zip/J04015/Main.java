package J04015;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String s1 = scn.nextLine(), s2 = scn.nextLine();
        int s3 = scn.nextInt();
        GiaoVien a = new GiaoVien(s1, s2, s3);
        System.out.println(a);
    }
}
