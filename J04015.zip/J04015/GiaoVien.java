package J04015;

import java.math.BigInteger;

public class GiaoVien {
    private String chucVu, heSo, hoTen;
    private int luongCoBan;
    GiaoVien(String maNgach, String hoTen, int luongCoBan) {
        this.chucVu = maNgach.substring(0, 2);
        this.heSo = maNgach.substring(2, 4);
        this.hoTen = hoTen;
        this.luongCoBan = luongCoBan;
    }

    @Override
    public String toString() {
        int phuCap = 0;
        switch (chucVu) {
            case "HT":
                phuCap = 2000000;
                break;
            case "HP":
                phuCap = 900000;
                break;
            case "GV":
                phuCap = 500000;
                break;
        }
        int luong = luongCoBan * Integer.parseInt(heSo) + phuCap;
        int hS = Integer.parseInt(heSo);
        return String.format("%s%s %s %d %d %d", chucVu, heSo, hoTen, hS, phuCap, luong);
    }
}
