package J04003;

import java.math.BigInteger;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        BigInteger a = scn.nextBigInteger(), b = scn.nextBigInteger();
        PhanSo ps = new PhanSo(a, b);
        System.out.println(ps.rutGon());
    }
}