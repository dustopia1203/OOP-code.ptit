package J04003;

import java.math.BigInteger;

public class PhanSo {
    private BigInteger tuSo, mauSo;

    PhanSo(BigInteger a, BigInteger b) {
        tuSo = a;
        mauSo = b;
    }

    public PhanSo rutGon() {
        return new PhanSo(tuSo.divide(tuSo.gcd(mauSo)), mauSo.divide(tuSo.gcd(mauSo)));
    }

    @Override
    public String toString() {
        return tuSo.toString() + "/" + mauSo.toString();
    }
}