package J05007;

public class NhanVien implements Comparable<NhanVien> {
    private static int cnt = 0;
    private String id = String.format("%05d", ++cnt);
    private String name, sex, dob, address, taxNumber, contractDay;

    public NhanVien(String name, String sex, String dob, String address, String taxNumber, String contractDay) {
        this.name = name;
        this.sex = sex;
        this.dob = dob;
        this.address = address;
        this.taxNumber = taxNumber;
        this.contractDay = contractDay;
    }

    @Override
    public String toString() {
        return id + " " + name + " " + sex + " " + dob + " " + address + " " + taxNumber + " " + contractDay;
    }

    @Override
    public int compareTo(NhanVien o) {
        String[] t1 = dob.split("/");
        String[] t2 = o.dob.split("/");
        if (t1[2].equals(t2[2])) {
            if (t1[1].equals(t2[1])) {
                return t1[0].compareTo(t2[0]);
            } else return t1[1].compareTo(t2[1]);
        } else return t1[2].compareTo(t2[2]);
    }
}
