package J05007;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        ArrayList<NhanVien> a = new ArrayList<>();
        int n = Integer.parseInt(scn.nextLine());
        while (n-- > 0) {
            a.add(new NhanVien(scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine(), scn.nextLine()));
        }
        Collections.sort(a);
        for (NhanVien i : a) {
            System.out.println(i);
        }
    }
}
