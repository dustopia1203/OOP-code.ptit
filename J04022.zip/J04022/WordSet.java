package J04022;

import java.util.Arrays;
import java.util.TreeSet;

public class WordSet {
    private TreeSet<String> ts = new TreeSet<>();

    public WordSet(String s) {
        s = s.toLowerCase();
        ts.addAll(Arrays.asList(s.split("\\s")));
    }

    public WordSet(TreeSet<String> ans) {
        ts = ans;
    }

    public WordSet union(WordSet s2) {
        TreeSet<String> ans = new TreeSet<>(ts);
        ans.addAll(s2.ts);
        return new WordSet(ans);
    }

    public WordSet intersection(WordSet s2) {
        TreeSet<String> ans = new TreeSet<>();
        for (String i : ts) {
            if (s2.ts.contains(i)) ans.add(i);
        }
        return new WordSet(ans);
    }

    @Override
    public String toString() {
        String s = "";
        for (String i : ts) {
            s += i + " ";
        }
        return s;
    }
}
