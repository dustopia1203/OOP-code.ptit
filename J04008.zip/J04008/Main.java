package J04008;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int t = scn.nextInt();
        while (t-- > 0) {
            double[] a = new double[6];
            for (int i = 0; i < 6; i++) a[i] = scn.nextDouble();
            Point p1 = new Point(a[0], a[1]), p2 = new Point(a[2], a[3]), p3 = new Point(a[4], a[5]);
            double AB = p1.distance(p2), BC = p2.distance(p3), AC = p1.distance(p3);
            if (AB + AC <= BC || AB + BC <= AC || AC + BC <= AB) {
                System.out.println("INVALID");
            }
            else {
                double res = AB + AC + BC;
                System.out.printf("%.3f\n", res);
            }
        }
    }
}
